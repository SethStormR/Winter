Lightworks Winter icons
-----------------------------
Copy the *.png image file to /usr/share/lightworks/Icons